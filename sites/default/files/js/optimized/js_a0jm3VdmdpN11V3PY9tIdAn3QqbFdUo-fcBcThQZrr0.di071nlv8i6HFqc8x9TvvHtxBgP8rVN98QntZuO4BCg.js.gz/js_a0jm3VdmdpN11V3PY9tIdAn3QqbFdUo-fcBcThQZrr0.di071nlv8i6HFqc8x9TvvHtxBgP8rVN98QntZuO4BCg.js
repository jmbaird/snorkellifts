/* Source and licensing information for the line(s) below can be found at http://www.snorkellifts.com/core/misc/polyfills/nodelist.foreach.js. */
;if(window.NodeList&&!NodeList.prototype.forEach){NodeList.prototype.forEach=Array.prototype.forEach};
/* Source and licensing information for the above line(s) can be found at http://www.snorkellifts.com/core/misc/polyfills/nodelist.foreach.js. */