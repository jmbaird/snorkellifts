/* Source and licensing information for the line(s) below can be found at http://www.snorkellifts.com/modules/contrib/blazy/js/base/blazy.base.min.js. */
!function(e,n,i){"use strict";e.debounce=function(c,t,e,i){n.debounce(function(){c.call(e,t)},i||201,!0)},e.matchMedia=function(c,t){return!!i.matchMedia&&(e.isUnd(t)&&(t="max"),i.matchMedia("("+t+"-device-width: "+c+")").matches)}}(dBlazy,Drupal,this);

/* Source and licensing information for the above line(s) can be found at http://www.snorkellifts.com/modules/contrib/blazy/js/base/blazy.base.min.js. */