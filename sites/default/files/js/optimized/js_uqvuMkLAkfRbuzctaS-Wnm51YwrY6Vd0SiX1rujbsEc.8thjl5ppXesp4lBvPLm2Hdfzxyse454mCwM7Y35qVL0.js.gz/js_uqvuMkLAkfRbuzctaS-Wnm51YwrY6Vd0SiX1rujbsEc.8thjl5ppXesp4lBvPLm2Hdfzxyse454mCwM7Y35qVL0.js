/* Source and licensing information for the line(s) below can be found at http://www.snorkellifts.com/core/modules/toolbar/js/models/MenuModel.js. */
(function(e,o){o.toolbar.MenuModel=e.Model.extend({defaults:{subtrees:{}}})})(Backbone,Drupal);
/* Source and licensing information for the above line(s) can be found at http://www.snorkellifts.com/core/modules/toolbar/js/models/MenuModel.js. */